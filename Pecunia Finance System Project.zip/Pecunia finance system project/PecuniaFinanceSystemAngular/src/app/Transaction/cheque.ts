export class Cheque
{
    chequeId:number;
    chequeNo:number;
    chequeAmount:number;
    chequeDated:Date;
    chequeAccountNo:number;
}