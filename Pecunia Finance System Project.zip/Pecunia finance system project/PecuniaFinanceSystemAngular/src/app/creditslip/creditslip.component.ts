
import { Component, OnInit } from '@angular/core';
import { Transaction, MyserviceService } from '../myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-creditslip',
  templateUrl: './creditslip.component.html',
  styleUrls: ['./creditslip.component.css']
})
export class CreditslipComponent implements OnInit {

  message:string;
constructor(private tservice: MyserviceService,private router: Router) { }

ngOnInit(): void {
}
onSubmit(creditslip:Transaction):any{
  if(creditslip.amount==0)
    this.message="Amount Cannot be Zero";
  
  else{
  console.log(creditslip);
   this.tservice.creditUsingSlip(creditslip).subscribe(data => {
    this.message=data});
   }
  
}
  }
  
  

  
