package com.capgemini.pecunia.bean;

public class Pecunia {

}
