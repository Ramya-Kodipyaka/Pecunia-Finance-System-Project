package com.capgemini.pecunia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PecuniaFinanceSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PecuniaFinanceSystemApplication.class, args);
	}

}
